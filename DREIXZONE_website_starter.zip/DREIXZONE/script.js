// DREIXZONE starter app. Replace sample content with verified current-patch data.
const heroes = [
  {name:"Miya",role:"Marksman",lane:"Gold Lane",specialty:"Reap / Damage",passive:"Turbo — basic attacks can increase attack speed. Check the current in-game description for exact values.",skills:["Moon Arrow: enhances basic attacks.","Arrow of Eclipse: control skill.","Rain of Arrows: area damage and slow.","Hidden Moonlight: concealment and repositioning."],tip:"Farm safely in the early game, watch the minimap, and deal sustained damage from the back line.",spell:"Inspire or Flicker (match-up dependent)",emblem:"Marksman (adjust talents to the enemy lineup)",build:["Swift Boots","Haas's Claws","Berserker's Fury","Windtalker","Malefic Roar","Immortality"],tier:"A"},
  {name:"Tigreal",role:"Tank",lane:"Roam",specialty:"Crowd Control",passive:"Fearless — defensive passive; review the current client for exact mechanics.",skills:["Attack Wave: ranged slow.","Sacred Hammer: engage and displacement.","Implosion: area crowd control."],tip:"Look for safe team-fight openings. Communicate before committing your ultimate.",spell:"Flicker",emblem:"Tank",build:["Tough Boots","Dominance Ice","Athena's Shield","Antique Cuirass","Immortality","Radiant Armor"],tier:"A"},
  {name:"Zilong",role:"Fighter",lane:"EXP Lane",specialty:"Chase / Burst",passive:"Dragon Flurry — basic attacks build toward a stronger strike.",skills:["Spear Flip: disrupts a target.","Spear Strike: gap closer.","Supreme Warrior: boosts mobility and combat pressure."],tip:"Use side-lane pressure and choose isolated targets. Avoid starting fights while outnumbered.",spell:"Execute or Inspire",emblem:"Assassin or Fighter",build:["Tough Boots","Windtalker","Berserker's Fury","Haas's Claws","Malefic Roar","Immortality"],tier:"B"},
  {name:"Layla",role:"Marksman",lane:"Gold Lane",specialty:"Finisher / Damage",passive:"Malefic Gun — attack range increases with level.",skills:["Malefic Bomb: ranged poke.","Void Projectile: slow and damage.","Destruction Rush: long-range ultimate."],tip:"Maintain distance and use your range advantage. Stay near teammates when enemies can dive.",spell:"Flicker",emblem:"Marksman",build:["Swift Boots","Haas's Claws","Berserker's Fury","Windtalker","Malefic Roar","Wind of Nature"],tier:"B"},
  {name:"Eudora",role:"Mage",lane:"Mid Lane",specialty:"Control / Burst",passive:"Superconductor — skills can apply an effect that improves follow-up damage.",skills:["Forked Lightning: area damage.","Ball Lightning: stun and burst.","Thunder's Wrath: powerful magic burst."],tip:"Use bushes carefully to create picks, but avoid spending all skills before the enemy team is in range.",spell:"Flicker",emblem:"Mage",build:["Arcane Boots","Genius Wand","Lightning Truncheon","Holy Crystal","Divine Glaive","Winter Crown"],tier:"A"},
  {name:"Alucard",role:"Fighter",lane:"Jungle",specialty:"Chase / Damage",passive:"Pursuit — skills and basic attacks support chasing and damage.",skills:["Groundsplitter: leap and damage.","Whirling Smash: area damage.","Fission Wave: empowered attacks and sustain."],tip:"Track enemy crowd-control skills before diving. Enter fights when key threats are occupied.",spell:"Retribution",emblem:"Assassin or Fighter",build:["Tough Boots","War Axe","Endless Battle","Malefic Roar","Queen's Wings","Immortality"],tier:"B"},
  {name:"Fanny",role:"Assassin",lane:"Jungle",specialty:"Chase / Reap",passive:"Air Superiority — mobility helps her deal damage while moving.",skills:["Tornado Strike: area damage.","Steel Cable: high-mobility cable movement.","Cut Throat: finishing damage."],tip:"Practice movement in training mode and track energy carefully. Coordinate dives with your team.",spell:"Retribution",emblem:"Assassin",build:["Tough Boots","Blade of the Heptaseas","Hunter Strike","Malefic Roar","Rose Gold Meteor","Immortality"],tier:"A"}
];

const $ = (id) => document.getElementById(id);
let selectedRole = "All";
const favorites = new Set(JSON.parse(localStorage.getItem("dzFavorites") || "[]"));

function renderHeroes(){
  const query = $("heroSearch").value.trim().toLowerCase();
  const role = $("roleFilter").value;
  const lane = $("laneFilter").value;
  const filtered = heroes.filter(h => (role==="All" || h.role===role) && (lane==="All" || h.lane===lane) && h.name.toLowerCase().includes(query));
  $("heroCount").textContent = `${filtered.length} HEROES`;
  $("heroGrid").innerHTML = filtered.map(h => `
    <article class="hero-card" data-hero="${h.name}">
      <div class="hero-symbol">${h.name.slice(0,1)}</div><h3>${h.name}</h3>
      <div class="hero-meta">${h.role.toUpperCase()} · ${h.lane.toUpperCase()}</div>
      <button class="favorite ${favorites.has(h.name)?"active":""}" data-favorite="${h.name}" aria-label="Favorite ${h.name}">${favorites.has(h.name)?"★":"☆"}</button>
    </article>`).join("") || `<p class="fine-print">No heroes found. Try another search or filter.</p>`;
  document.querySelectorAll(".hero-card").forEach(card => card.addEventListener("click", e => {
    if(e.target.closest("[data-favorite]")) return;
    showHero(card.dataset.hero);
  }));
  document.querySelectorAll("[data-favorite]").forEach(btn => btn.addEventListener("click", e => {
    e.stopPropagation(); const name=btn.dataset.favorite;
    favorites.has(name)?favorites.delete(name):favorites.add(name);
    localStorage.setItem("dzFavorites",JSON.stringify([...favorites])); renderHeroes();
  }));
}
function showHero(name){
  const h=heroes.find(x=>x.name===name); if(!h)return;
  $("heroDetails").innerHTML = `<p class="eyebrow">${h.role.toUpperCase()} · ${h.lane.toUpperCase()}</p><h2 id="modalName">${h.name}</h2><p>${h.specialty}</p><h3>Passive</h3><p>${h.passive}</p><h3>Skills</h3><ul>${h.skills.map(s=>`<li>${s}</li>`).join("")}</ul><h3>How to use</h3><p>${h.tip}</p><h3>Suggested setup</h3><p><b>Spell:</b> ${h.spell}<br><b>Emblem:</b> ${h.emblem}</p><h3>Starter build</h3><p>${h.build.join(" · ")}</p><p class="fine-print">Sample guide only. Verify all skills, item effects, and builds in the current game version.</p>`;
  $("heroModal").classList.add("open"); $("heroModal").setAttribute("aria-hidden","false");
}
function closeModal(){ $("heroModal").classList.remove("open"); $("heroModal").setAttribute("aria-hidden","true"); }
function renderBuild(){
  const h=heroes.find(x=>x.name===$("buildHero").value); if(!h)return;
  $("buildInfo").innerHTML=`<h3>${h.name}</h3><p>${h.role} · ${h.lane}</p><p>${h.tip}</p><p><b>Battle spell:</b> ${h.spell}</p><p><b>Emblem:</b> ${h.emblem}</p>`;
  $("buildItems").innerHTML=h.build.map((item,i)=>`<div class="item-chip"><div class="item-icon">${["✦","⚔","◈","✧","⬡","◆"][i]}</div><b>${item}</b><span>Suggested slot ${i+1}</span></div>`).join("");
}
function renderTiers(){
  const tiers=["S+","S","A","B","C"];
  const descriptions={"S+":"Top priority picks","S":"Strong picks","A":"Reliable options","B":"Situational picks","C":"Needs favorable conditions"};
  $("tierList").innerHTML=tiers.map(t=>{const names=heroes.filter(h=>h.tier===t).map(h=>h.name);return `<div class="tier-row"><div class="tier-label">${t}</div><div class="tier-heroes"><span>${descriptions[t]}</span>${names.length?names.map(n=>`<span>${n}</span>`).join(""):"<span>Not assigned</span>"}</div></div>`}).join("");
}
$("heroSearch").addEventListener("input",renderHeroes);
$("roleFilter").addEventListener("change",renderHeroes);
$("laneFilter").addEventListener("change",renderHeroes);
$("modalClose").addEventListener("click",closeModal);
$("heroModal").addEventListener("click",e=>{if(e.target===$("heroModal"))closeModal()});
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal()});
$("buildHero").innerHTML=heroes.map(h=>`<option>${h.name}</option>`).join("");
$("buildHero").addEventListener("change",renderBuild);
$("profileSearch").addEventListener("click",()=>{
  const user=$("userId").value.trim(), server=$("serverId").value.trim();
  if(!/^\d+$/.test(user)||!/^\d+$/.test(server)){ $("profileResult").innerHTML=`<div class="profile-placeholder">!</div><div><h3>Check your IDs</h3><p>Enter numeric User ID and Server ID. Never enter your password.</p></div>`;return; }
  $("profileResult").innerHTML=`<div class="profile-placeholder">DZ</div><div><p class="eyebrow">LOCAL DEMO PREVIEW</p><h3>Player ${user}</h3><p>Server ID: ${server}<br>This is only a local preview. Real rank, matches, win rate, avatar, and battle history require an authorized data provider or official integration.</p></div>`;
});
$("menuToggle").addEventListener("click",()=>$("mainNav").classList.toggle("open"));
document.querySelectorAll("#mainNav a").forEach(a=>a.addEventListener("click",()=>$("mainNav").classList.remove("open")));
renderHeroes();renderBuild();renderTiers();
