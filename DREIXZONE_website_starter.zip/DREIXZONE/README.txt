# DREIXZONE — MLBB companion starter

## Run the website
1. Extract the ZIP.
2. Open the `DREIXZONE` folder in VS Code.
3. Open `index.html`.
4. If you have Live Server installed, right-click `index.html` and choose **Open with Live Server**.

## Files
- `index.html` — page structure and sections
- `style.css` — dark fantasy gaming design and responsive layout
- `script.js` — sample hero data, search/filter, modal, favorites, build selector, tier display, and profile demo

## Important limitations
- The player lookup is a UI demo. It does **not** connect to Moonton, and it does not retrieve actual account statistics. Do not collect MLBB passwords. Real player data needs an authorized API/provider, compliance with its terms, and a secure backend.
- Hero skills, builds, emblems, and tier placements are starter/sample content. Verify them against the current patch before publishing.
- Official MLBB artwork, item icons, and emblem images are not bundled. Use assets only where you have permission or a valid license. Put permitted files in `assets/`, then reference them with paths such as `assets/miya.webp`.
- DREIXZONE is an independent fan project and is not affiliated with Moonton.

## Suggested next improvements
1. Add a backend only after selecting a legitimate, authorized player-data provider.
2. Store patch data in a separate JSON file and include the patch/version date.
3. Add licensed hero portraits and item icons.
4. Add a build comparison interface and a patch-notes feed from reliable sources.
